/* Kalvi AI - adaptive tutor, runs fully in the browser (no server needed).
   Idea: every topic has a mastery score (0..1). A correct answer moves it towards 1,
   a wrong answer towards 0. The next question comes mostly from the weakest topic,
   at a difficulty that matches the mastery. */

// ---------------- Settings ----------------
const DIFFICULTIES = ["easy", "medium", "hard"];
const LEARNING_RATE = { easy: 0.25, medium: 0.30, hard: 0.35 };
const QUIZ_LENGTH = 10;
const START_MASTERY = 0.30;

// ---------------- Text in English and Tamil ----------------
const I18N = {
  en: { title:"Kalvi AI", welcome:"Welcome! Let's learn together.", yourName:"Your name",
        chooseSubject:"Choose a subject", note:"The tutor adjusts the questions to your level.",
        next:"Next", tips:"Your learning plan", again:"Practice again",
        correct:"✅ Correct!", wrong:"❌ Not quite.", question:"Question", streak:"Streak",
        score:"Score", mastery:"Mastery", finish:"See my report",
        Beginner:"Beginner", Improving:"Improving", Strong:"Strong",
        tipB:(t)=>`Revise the basics of ${t} - start with easy examples.`,
        tipI:(t)=>`Keep practising ${t} - you are getting better!`,
        tipS:(t)=>`Great work in ${t}! Try harder problems.` },
  ta: { title:"கல்வி AI", welcome:"வணக்கம்! சேர்ந்து கற்போம்.", yourName:"உங்கள் பெயர்",
        chooseSubject:"பாடத்தைத் தேர்ந்தெடுக்கவும்", note:"உங்கள் நிலைக்கு ஏற்ப கேள்விகள் மாறும்.",
        next:"அடுத்தது", tips:"உங்கள் கற்றல் திட்டம்", again:"மீண்டும் பயிற்சி",
        correct:"✅ சரி!", wrong:"❌ தவறு.", question:"கேள்வி", streak:"தொடர்",
        score:"மதிப்பெண்", mastery:"தேர்ச்சி", finish:"என் அறிக்கையைப் பார்",
        Beginner:"தொடக்கநிலை", Improving:"முன்னேறுகிறது", Strong:"வலுவானது",
        tipB:(t)=>`${t} அடிப்படைகளை மீண்டும் படியுங்கள் - எளிய கேள்விகளிலிருந்து தொடங்குங்கள்.`,
        tipI:(t)=>`${t} பயிற்சியைத் தொடருங்கள் - நீங்கள் முன்னேறுகிறீர்கள்!`,
        tipS:(t)=>`${t} இல் சிறப்பு! கடினமான கேள்விகளை முயற்சிக்கவும்.` },
};

// ---------------- Adaptive engine ----------------
const difficultyFor = (m) => (m < 0.40 ? "easy" : m < 0.70 ? "medium" : "hard");
const levelFor = (m) => (m < 0.40 ? "Beginner" : m < 0.70 ? "Improving" : "Strong");
const subjectsList = () => [...new Set(QUESTION_BANK.map((q) => q.subject))].sort();
const topicsOf = (s) => [...new Set(QUESTION_BANK.filter((q) => q.subject === s).map((q) => q.topic))].sort();

// Progress is saved in the browser (localStorage) so a student can continue later
const storeKey = "kalviProgress";
const loadAll = () => { try { return JSON.parse(localStorage.getItem(storeKey)) || {}; } catch { return {}; } };
const saveAll = (d) => { try { localStorage.setItem(storeKey, JSON.stringify(d)); } catch {} };

function newSession(name, subject) {
  name = name.trim() || "Student";
  const saved = loadAll()[`${name.toLowerCase()}::${subject}`] || {};
  const mastery = {};
  topicsOf(subject).forEach((t) => (mastery[t] = saved[t] ?? START_MASTERY));
  return { name, subject, mastery, asked: new Set(), history: [], current: null, streak: 0 };
}

function pickNext(s) {
  if (s.history.length >= QUIZ_LENGTH) return null;
  const pool = QUESTION_BANK.filter((q) => q.subject === s.subject && !s.asked.has(q.id));
  if (!pool.length) return null;
  // weaker topics are more likely to be chosen
  const topics = Object.keys(s.mastery);
  const weights = topics.map((t) => 1 - s.mastery[t] + 0.1);
  let r = Math.random() * weights.reduce((a, b) => a + b, 0), topic = topics[0];
  for (let i = 0; i < topics.length; i++) { r -= weights[i]; if (r <= 0) { topic = topics[i]; break; } }
  const want = DIFFICULTIES.indexOf(difficultyFor(s.mastery[topic]));
  let candidates = pool.filter((q) => q.topic === topic);
  if (!candidates.length) candidates = pool;
  const gap = (q) => Math.abs(DIFFICULTIES.indexOf(q.difficulty) - want);
  const best = Math.min(...candidates.map(gap));
  const closest = candidates.filter((q) => gap(q) === best);
  s.current = closest[Math.floor(Math.random() * closest.length)];
  return s.current;
}

function submitAnswer(s, choice) {
  const q = s.current;
  const correct = choice === q.answer;
  const old = s.mastery[q.topic];
  s.mastery[q.topic] = old + LEARNING_RATE[q.difficulty] * ((correct ? 1 : 0) - old);
  s.streak = correct ? s.streak + 1 : 0;
  s.asked.add(q.id);
  s.history.push({ topic: q.topic, correct });
  const all = loadAll();
  all[`${s.name.toLowerCase()}::${s.subject}`] = s.mastery;
  saveAll(all);
  s.current = null;
  return { correct, q, finished: s.history.length >= QUIZ_LENGTH };
}

// ---------------- User interface ----------------
let lang = "en", session = null, current = null, answered = false, finished = false;
const $ = (id) => document.getElementById(id);
const t = (k) => I18N[lang][k];

function applyLang() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach((el) => (el.textContent = t(el.dataset.i18n)));
  $("langBtn").textContent = lang === "en" ? "தமிழ்" : "English";
  if (finished && !$("nextBtn").classList.contains("hidden")) $("nextBtn").textContent = t("finish");
}
$("langBtn").onclick = () => { lang = lang === "en" ? "ta" : "en"; applyLang(); };

function show(id) { ["start", "quiz", "report"].forEach((s) => $(s).classList.toggle("hidden", s !== id)); }

// subject buttons
subjectsList().forEach((sub) => {
  const b = document.createElement("button");
  b.className = "subject"; b.textContent = sub;
  b.onclick = () => {
    session = newSession($("name").value, sub);
    finished = false;
    renderQuestion(pickNext(session));
    show("quiz");
  };
  $("subjects").appendChild(b);
});

function renderQuestion(q) {
  current = q; answered = false;
  $("progress").textContent = `${t("question")} ${session.history.length + 1}/${QUIZ_LENGTH}`;
  $("topic").textContent = q.topic; $("diff").textContent = q.difficulty;
  $("barFill").style.width = (session.history.length / QUIZ_LENGTH) * 100 + "%";
  $("question").textContent = q.question;
  $("options").innerHTML = "";
  q.options.forEach((text, i) => {
    const b = document.createElement("button");
    b.className = "opt"; b.textContent = text; b.onclick = () => choose(i);
    $("options").appendChild(b);
  });
  $("feedback").classList.add("hidden"); $("nextBtn").classList.add("hidden");
}

function choose(i) {
  if (answered) return; answered = true;
  const r = submitAnswer(session, i);
  const btns = document.querySelectorAll(".opt");
  btns.forEach((b) => (b.disabled = true));
  btns[r.q.answer].classList.add("right");
  if (!r.correct) btns[i].classList.add("wrong");
  const m = Math.round(session.mastery[r.q.topic] * 100);
  $("feedback").innerHTML = `<b>${r.correct ? t("correct") : t("wrong")}</b> ${r.q.explanation}<br><small>${t("mastery")} (${r.q.topic}): ${m}%</small>`;
  $("feedback").classList.remove("hidden");
  $("streak").textContent = session.streak > 1 ? `🔥 ${t("streak")}: ${session.streak}` : "";
  finished = r.finished;
  $("nextBtn").textContent = finished ? t("finish") : t("next");
  $("nextBtn").classList.remove("hidden");
}

$("nextBtn").onclick = () => {
  if (finished) return showReport();
  const q = pickNext(session);
  q ? renderQuestion(q) : showReport();
};

function showReport() {
  const total = session.history.length;
  const right = session.history.filter((h) => h.correct).length;
  const rows = Object.entries(session.mastery).map(([topic, m]) => ({ topic, m, level: levelFor(m) })).sort((a, b) => a.m - b.m);
  $("repTitle").textContent = `${session.name} - ${session.subject}`;
  $("repScore").textContent = `${t("score")}: ${right}/${total} (${total ? Math.round((100 * right) / total) : 0}%)`;
  $("repTopics").innerHTML = rows.map((x) =>
    `<div class="trow"><div class="lbl"><span>${x.topic} · ${t(x.level)}</span><span>${Math.round(x.m * 100)}%</span></div>
     <div class="track"><div class="fill" style="width:${Math.round(x.m * 100)}%"></div></div></div>`).join("");
  $("repTips").innerHTML = rows.map((x) =>
    `<li>${x.level === "Beginner" ? t("tipB")(x.topic) : x.level === "Improving" ? t("tipI")(x.topic) : t("tipS")(x.topic)}</li>`).join("");
  show("report");
}
$("again").onclick = () => show("start");
applyLang();
