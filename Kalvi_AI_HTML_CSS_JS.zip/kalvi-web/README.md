# Kalvi AI - Adaptive AI Tutor (HTML + CSS + JavaScript)
SDG 4: Quality Education | IBM SkillsBuild project

No Python, no server, no installation needed.

## Run in VS Code
1. Unzip and open the `kalvi-web` folder in VS Code (File > Open Folder).
2. Install the extension **Live Server** (by Ritwick Dey): Extensions icon > search "Live Server" > Install.
3. Right-click `index.html` > **Open with Live Server**.
   The page opens at http://127.0.0.1:5500 and refreshes automatically when you save.

(Without Live Server you can also just double-click `index.html` to open it in Chrome or Edge.)

## Files
- index.html     page layout
- style.css      design
- questions.js   36 questions (Maths, Science, English) - add your own here
- app.js         adaptive engine + Tamil/English + quiz screens + report

## How the adaptive logic works
- Each topic starts at mastery 0.30.
- After each answer: mastery = mastery + rate x (result - mastery); result is 1 (correct) or 0 (wrong).
  rate = 0.25 easy, 0.30 medium, 0.35 hard.
- mastery below 0.40 gives easy questions, 0.40-0.70 medium, above 0.70 hard.
- Weaker topics are asked more often. A quiz has 10 questions, then a report and study plan.
- Progress is saved in the browser (localStorage), so the student continues next time.

## Add a question
In questions.js add a line like:
{"id":36,"subject":"Maths","topic":"Fractions","difficulty":"easy","question":"1/4 + 1/4 = ?","options":["1/8","1/2","1","2"],"answer":1,"explanation":"Two quarters make a half."},
Use a new unique id.
